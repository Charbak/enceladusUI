function prompt_confirm() {

	var bool = confirm("Are You sure you want to make update details");

	return bool;

}

function win_close() {
	
	self.close();

}