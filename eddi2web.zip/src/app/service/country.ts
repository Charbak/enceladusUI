export interface ICountry {
    country_name: string,
    load_port: string,
    currency: string
}