import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menutab',
  templateUrl: './menutab.component.html',
  styleUrls: ['./menutab.component.css']
})
export class MenutabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
